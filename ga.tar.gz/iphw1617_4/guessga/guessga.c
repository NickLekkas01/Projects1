
/*
 * You dirty minded freak! You want some comments? I will give you some comments!
 *
 * A project made by Kostas  Alexopoulos (souperk) and Nikos Lekkas. 
 * 
 * We bring no responsibilty for any damage done to your property by the current software.
 *
 * However, some any damage done to your brain by the comments, you may accuse Kostas Alexopoulos.
 *
 * Compilation Instructions :
 * Pending....
 *
 * Execution Instructions : 
 * 
 * -FT <FT> : for setting the fitness goal. Can have any integer value. Default value is 1024 ( = 32 * 32 ).
 * -P <P> : for setting population size. Can have any integer value. Default value is 10.
 * -G <G> : for setting the generation size. Can have any integer value. Default value is 50.
 * -PC <PC> : for setting the probabilty of crossing. Can have any real value in [0,1] . Default value is 0.3 .
 * -PM <PM> : for setting the probability of mutation. Can have any real value in [0,1]. Default value is  0.1 .
 * 
 * 
 */

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <math.h>

#include "genetic_algorithm.h"

Chromosome* number;
int size;

void print(Chromosome* c)
{
    int i;
    
    /* print in reverse. */
    for( i = size - 1; i >= 0;  i--)
    {
        printf("%d", ((int*)c->genes)[i]); 
    }
}

Chromosome* scan()
{
    Chromosome* c = malloc(sizeof(Chromosome));
    int capacity = 32;
    c->genes = malloc(sizeof(int) * capacity);
    size = 0;

    /* find size */
    char ch;
    while((ch=getchar()) != '\n')
    {
        if(size == capacity)
            c->genes = realloc(c->genes, sizeof(int) * (capacity+=32)); 
        ((int*)c->genes)[size++] = ch - '0';
    }

    //get rid of unused space.
    c->genes = realloc(c->genes, sizeof(int) * size);
    
    /* Reverse. */
    int i;
    for( i = 0; i < size / 2; i++ )
    {
        swap( &c->genes[i] , &c->genes[size - 1 - i] );
    }

    return c;
}

/*
 * Returns the fitness as described the excerise description.
 *
 */
double fitness(Chromosome* c)
{	
    double count = 0; 
    int i;
    
    for( i=0; i < size; i++)
    {
        if(((int*)c->genes)[i] == ((int*)number->genes)[i])
            count ++ ;
    }

    return count * count;
}

Chromosome* randChromosome()
{
   Chromosome* c = malloc(sizeof(Chromosome));
   c->genes = malloc(sizeof(int) * size);

   int i;
   for( i = 0; i < size; i++)
   {
        ((int*)c->genes)[i] = rand() & 1;
   }

    return c;
}

/*
 * Picks a random crossing point and crosses a and b on that point.
 */
void cross(Chromosome* a, Chromosome* b)
{
	int i = (rand() % size) + 1;

    int* A = malloc(sizeof(int) * size);
    int* B = malloc(sizeof(int) * size);

    int j;
    for( j = 0; j < i; j++)
    {
        A[j] = ((int*)a->genes)[j];
        B[j] = ((int*)b->genes)[j];
    }

    for( j = i; j < size; j++)
    {
        A[j] = ((int*)b->genes)[j];
        B[j] = ((int*)a->genes)[j];
    }

    a->genes = A;
    b->genes = B;
}

void mutate(Chromosome* c, int gene)
{
    ((int*)c->genes)[gene] = !((int*) c->genes)[gene];
}

Chromosome* copy(Chromosome* c)
{        
    Chromosome* copy = malloc(sizeof(Chromosome));

    copy->fitness = c->fitness;
    copy->genes = malloc(sizeof(int)*size);

    int i;
    for(i = 0; i < size; i++)
    {
        ((int*)copy->genes)[i] = ((int*)c->genes)[i];
    }

    return copy;
}

/*
 * 
 */
void parseArguments(int argc, int* argv[], GeneticAlgorithm* algo)
{
	algo->populationSize = 100;
	algo->generationsSize = 100;
	algo->fitnessGoal = 1024;
	algo->crossingPropability = 0.3;
    algo->mutationPropability = 0.1;
   
    algo->elites = 50;

	int i;
	for( i = 1; i < argc; i++)
	{
		int * option = argv[i];
		if(strcmp(option, "-P") == 0)
		{
			algo->populationSize = atoi(argv[++i]);
		}else if(strcmp(option, "-G") == 0)
		{
			algo->generationsSize = atoi(argv[++i]);
		}else if(strcmp(option, "-FT") == 0)
		{
			algo->fitnessGoal =  atoi(argv[++i]);
		}else if(strcmp(option, "-PC") == 0)
		{
			sscanf(argv[++i], "%lf", &(algo->crossingPropability));
		}else if(strcmp(option, "-PM") == 0)
		{
			sscanf(argv[++i], "%lf", &(algo->mutationPropability));
		}else
		{
			printf("You dummy !! Look at the README for the proper usage format!!");
			exit(1);
		}
	}
}

int main(int argc, int* argv[])
{
    GeneticAlgorithm algo;

    algo.randChromosome = &randChromosome;
    algo.fitness = &fitness;
    algo.cross = &cross;
    algo.mutate = &mutate;
    algo.copy = &copy;
    algo.drand = &drand;

	parseArguments(argc, argv, &algo);
	
	printf("Give me the binary number : \n");
	number=scan(); 			//100011100101100111000101010101
    
    algo.geneSize = size;

    srand(time(NULL));

    Chromosome* max = apply(&algo);
	
    printf("Your Number : ");
    print(number);
    printf("\n");

    printf("My guess    : ");
    print(max);
    printf("\n");
    

    printf("Fitness : %.0lf (%.0lf out of %d)\n", max->fitness, sqrt(max->fitness),
    size);

	return 0;
}
