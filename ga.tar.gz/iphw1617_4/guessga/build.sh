gcc -o guessga genetic_algorithm.c guessga.c -lm
