gcc -w -o tspga tsp_parser.c genetic_algorithm.c tspga.c -lm

