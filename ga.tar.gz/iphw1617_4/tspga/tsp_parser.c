#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "tsp_parser.h"

typedef char bool;
const char false = 0;
const char true = 1;

int _max(int a, int b)
{
	if (a > b)
		return a;
	return b;
}

int _max3(int a, int b, int c)
{
	if (a > b)
		return _max(a, c);

	return _max(b, c);
}

bool startsWith(const char *pre, const char *str)
{
	size_t lenpre = strlen(pre), lenstr = strlen(str);
	return lenstr < lenpre ? false : strncmp(pre, str, lenpre) == 0;
}

bool isWhiteSpace(char ch)
{
	if (ch == ' ' || ch == '\t')
		return true;
	return false;
}

char* parseLine()
{
	int size = 0;
	int capacity = 30;
	char* line = malloc(sizeof(char) * capacity);
	char ch;

	while ((ch = getchar()) != '\n' && ch != EOF)
	{
		line[size++] = ch;

		if (size == capacity)
		{
			line = realloc(line, sizeof(char) * (capacity += 30));
		}
	}

	line[size] = '\0';

	return line;
}

bool isAlphaNumeric(char ch)
{
	if (ch >= '0' && ch <= '9')
		return true;
	if (ch >= 'a' && ch <= 'z')
		return true;
	if (ch >= 'A' && ch <= 'Z')
        return true;
    if(ch == '_')
        return true;

	return false;
}

void init(TSPi* tsp)
{
	tsp->coordType = NO_COORDS;
	tsp->displayType = NO_DISPLAY;
}

bool processSpecificationLine(TSPi* tsp, char* line)
{
	int i = 0;
	int j = 0;
	char* keyword = malloc(sizeof(char) * 31);

	//Skip whitespaces
	while (isWhiteSpace(line[i]))

		i++;

	while (isAlphaNumeric(line[i]) && j < 30)
	{
		keyword[j++] = line[i++];
	}

    keyword[j] = '\0';
	//Skip whitespaces
	while (isWhiteSpace(line[i]))
		i++;

	if (line[i] != ':')
	{
		return false; //probably not on specification part anymore
	}

	i++;

	char* value = malloc(sizeof(char) * 30);

	sscanf(line + i, "%s", value);

	if (strcmp(keyword, "NAME") == 0)
	{
		tsp->name = value;
		return true;
	} else if (strcmp(keyword, "TYPE") == 0)
	{
		if (strcmp(value, "TSP") != 0)
		{
			printf("Unable to handle this kind of problem. Only TSP supported.\n");
			exit(1);
		}

		tsp->type = TSP;
		return true;
	} else if (strcmp(keyword, "COMMENT") == 0)
	{
		tsp->comment = value;
		return true;
	} else if (strcmp(keyword, "DIMENSION") == 0)
	{
		tsp->dimension = atoi(value);
		return true;
	} else if (strcmp(keyword, "EDGE_WEIGHT_TYPE") == 0)
	{
		if (strcmp(value, "EXPLICIT") == 0)
		{
			tsp->weightType = EXPLICIT;
		} else if (strcmp(value, "EUC_2D") == 0)
		{
			tsp->weightType = EUC_2D;
		} else if (strcmp(value, "EUC_3D") == 0)
		{
			tsp->weightType = EUC_3D;
		} else if (strcmp(value, "MAX_2D") == 0)
		{
			tsp->weightType = MAX_2D;
		} else if (strcmp(value, "MAX_3D") == 0)
		{
			tsp->weightType = MAX_3D;
		} else if (strcmp(value, "MAN_2D") == 0)
		{
			tsp->weightType = MAN_2D;
		} else if (strcmp(value, "MAN_3D") == 0)
		{
			tsp->weightType = MAN_3D;
		} else if (strcmp(value, "CEIL_2D") == 0)
		{
			tsp->weightType = CEIL_2D;
		} else if (strcmp(value, "GEO") == 0)
		{
			tsp->weightType = GEO;
		} else if (strcmp(value, "ATT") == 0)
		{
			tsp->weightType = ATT;
		} else if (strcmp(value, "XRAY1") == 0)
		{
			tsp->weightType = XRAY1;
		} else if (strcmp(value, "XRAY2") == 0)
		{
			tsp->weightType = XRAY2;
		} else
		{
			printf(" Unsupported edge weight type.\n");
			exit(1);
		}

		return true;
	} else if (strcmp(keyword, "EDGE_WEIGHT_FORMAT") == 0)
	{
		if (strcmp(value, "FUNCTION") == 0)
		{
			tsp->weightFormat = FUNCTION;
		} else if (strcmp(value, "FULL_MATRIX") == 0)
		{
			tsp->weightFormat = FULL_MATRIX;
		} else if (strcmp(value, "UPPER_ROW") == 0)
		{
			tsp->weightFormat = UPPER_ROW;
		} else if (strcmp(value, "LOWER_ROW") == 0)
		{
			tsp->weightFormat = LOWER_ROW;
		} else if (strcmp(value, "UPPER_DIAG_ROW") == 0)
		{
			tsp->weightFormat = UPPER_DIAG_ROW;
		} else if (strcmp(value, "LOWER_DIAG_ROW") == 0)
		{
			tsp->weightFormat = LOWER_DIAG_ROW;
		} else if (strcmp(value, "UPPER_COL") == 0)
		{
			tsp->weightFormat = UPPER_COL;
		} else if (strcmp(value, "LOWER_COL") == 0)
		{
			tsp->weightFormat = LOWER_COL;
		} else if (strcmp(value, "UPPER_DIAG_COL") == 0)
		{
			tsp->weightFormat = UPPER_DIAG_COL;
		} else if (strcmp(value, "LOWER_DIAG_COL") == 0)
		{
			tsp->weightFormat = LOWER_DIAG_COL;
		} else
		{
			printf(" Unsupported edge weight format.\n");
			exit(1);
		}

		return true;
	} else if (strcmp(keyword, "EDGE_DATA_FORMAT") == 0)
	{
		if (strcmp(value, "EDGE_LIST") == 0)
		{
			tsp->dataFormat = EDGE_LIST;
		} else if (strcmp(value, "ADJ_LIST") == 0)
		{
			tsp->dataFormat = ADJ_LIST;
		} else
		{
			printf(" Unsupported edge data format.\n");
			exit(1);
		}

		return true;
	} else if (strcmp(keyword, "NODE_COORD_TYPE") == 0)
	{
		if (strcmp(value, "TWOD_COORDS") == 0)
		{
			tsp->coordType = TWOD_COORDS;
		} else if (strcmp(value, "THREED_COORDS") == 0)
		{
			tsp->coordType = THREED_COORDS;
		} else if (strcmp(value, "NO_COORDS") == 0)
		{
			tsp->coordType = NO_COORDS;
		} else
		{
			printf("Unsupported node coord type : %s.\n", value);
			exit(1);
		}

		return true;
	} else if (strcmp(keyword, "DISPLAY_DATA_TYPE") == 0)
	{
		if (strcmp(value, "TWOD_DISPLAY") == 0)
		{
			tsp->displayType = TWOD_DISPLAY;
		} else if (strcmp(value, "COORD_DISPLAY") == 0)
		{
			tsp->displayType = COORD_DISPLAY;
		} else if (strcmp(value, "NO_DISPLAY") == 0)
		{
			tsp->displayType = NO_DISPLAY;
		} else
		{
			printf(" Unsupported node coord type .\n");
			exit(1);
		}

		return true;
	}
    printf("ret false\n");

	return false;
}

void parseNodeCoords(TSPi* tsp)
{
	int dim = 2;

	if (tsp->coordType == NO_COORDS)
	{
		printf(" Unsupported format!\n");
		exit(1);
	} else if (tsp->coordType == TWOD_COORDS)
	{
		dim = 2;
	} else if (tsp->coordType == THREED_COORDS)
	{
		dim = 3;
	}

	tsp->nodeCoords = malloc(sizeof(int*) * dim);
	int i, j;
	for (i = 0; i < dim; i++)
		tsp->nodeCoords[i] = malloc(sizeof(int) * tsp->dimension);

	for (i = 0; i < tsp->dimension; i++)
	{
		for (j = 0; j < dim; j++)
		{
			int temp;
			scanf("%d", &temp);
			tsp->nodeCoords[j][i] = temp;

		}
	}

	tsp->D = malloc(sizeof(int*) * tsp->dimension);
	for (i = 0; i < tsp->dimension; i++)
		tsp->D[i] = malloc(sizeof(int) * tsp->dimension);

	for (i = 0; i < tsp->dimension - 1; i++)
	{
		tsp->D[i][i] = 0;
		for (j = i + 1; j < tsp->dimension; j++)
		{
			int dist = 0;

			if (tsp->weightType == EUC_2D)
			{
				int xd = tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j];
				int yd = tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j];
				dist = (int) (sqrt(xd * xd + yd * yd) + 0.5);
			} else if (tsp->weightType == EUC_3D)
			{
				int xd = tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j];
				int yd = tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j];
				int zd = tsp->nodeCoords[2][i] - tsp->nodeCoords[2][j];
				dist = (int) (sqrt(xd * xd + yd * yd + zd * zd) + 0.5);
			} else if (tsp->weightType == MAN_2D)
			{
				int xd = abs(tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j]);
				int yd = abs(tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j]);
				dist = (int) (xd + yd + 0.5);
			} else if (tsp->weightType == MAN_3D)
			{
				int xd = abs(tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j]);
				int yd = abs(tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j]);
				int zd = abs(tsp->nodeCoords[2][i] - tsp->nodeCoords[2][j]);
				dist = (int) (xd + yd + zd + 0.5);
			} else if (tsp->weightType == MAX_2D)
			{
				int xd = abs(tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j]);
				int yd = abs(tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j]);
				dist = (int) (_max(xd, yd) + 0.5);
			} else if (tsp->weightType == MAN_3D)
			{
				int xd = abs(tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j]);
				int yd = abs(tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j]);
				int zd = abs(tsp->nodeCoords[2][i] - tsp->nodeCoords[2][j]);
				dist = (int) (_max3(xd, yd, zd) + 0.5);
			} else if (tsp->weightType == ATT)
			{
				int xd = tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j];
				int yd = tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j];

				int rij = sqrt((xd * xd + yd * yd) / 10.0);
				int tij = (int) (rij + 0.5);
				if (tij < rij)
					dist = tij + 1;
				else
					dist = tij;
			} else if (tsp->weightType == CEIL_2D)
			{
				int xd = tsp->nodeCoords[0][i] - tsp->nodeCoords[0][j];
				int yd = tsp->nodeCoords[1][i] - tsp->nodeCoords[1][j];
				dist = ceil((int) (sqrt(xd * xd + yd * yd) + 0.5));
			}

			tsp->D[i][j] = tsp->D[j][i] = dist;
		}
	}

}

void parseEdgeData(TSPi* tsp)
{
	//nothing assume there is a edge between every combination of cities.
}

void parseEdgeWeight(TSPi* tsp)
{
	int i, j;

	tsp->D = malloc(sizeof(int*) * tsp->dimension);

	for (i = 0; i < tsp->dimension; i++)
	{
		tsp->D[i] = malloc(sizeof(int) * tsp->dimension);
	}

	if (tsp->weightFormat == FULL_MATRIX)
	{
		for (i = 0; i < tsp->dimension; i++)
		{
			tsp->D[i][i] = 0;
			for (j = 0; j < tsp->dimension; j++)
			{
				int temp;
				scanf("%d", &temp);

				tsp->D[i][j] = temp;

			}
		}
	} else if (tsp->weightFormat == UPPER_ROW
			|| tsp->weightFormat == UPPER_DIAG_ROW
			|| tsp->weightFormat == UPPER_COL
			|| tsp->weightFormat == UPPER_DIAG_COL)
	{
		char diag = (tsp->weightFormat == UPPER_ROW
				|| tsp->weightFormat == UPPER_COL);

		for (i = 0; i < tsp->dimension - diag; i++)
		{
			for (j = i + diag; j < tsp->dimension; j++)
			{
				int temp;
				scanf("%d", &temp);

				tsp->D[i][j] = tsp->D[j][i] = temp;
			}
		}
	} else if (tsp->weightFormat == LOWER_ROW
			|| tsp->weightFormat == LOWER_DIAG_ROW
			|| tsp->weightFormat == LOWER_COL
			|| tsp->weightFormat == LOWER_DIAG_COL)
	{
		char diag = (tsp->weightFormat == LOWER_ROW
				|| tsp->weightFormat == LOWER_COL);

		for (i = diag; i < tsp->dimension ; i++)
		{
			for (j = 0 ; j < i - diag; j++)
			{
				int temp;
				scanf("%d", &temp);

				tsp->D[i][j] = tsp->D[j][i] = temp;
			}
		}
	}
    
    char ch;
    while(isWhiteSpace(ch=getchar()))
        ;
}

void parseDisplayData(TSPi* tsp)
{
    int i;

    for( i = 0; i < tsp->dimension; i++)
    {
        free(parseLine());
    }
}

TSPi* parse(char* filename)
{
    freopen(filename, "r", stdin);

	TSPi* tsp = malloc(sizeof(TSPi));

	char* line;

	while (processSpecificationLine(tsp, line = parseLine()))
	{
		free(line);
	}

	char* section = malloc(sizeof(char) * 30);

	sscanf(line, "%s", section);

	while (strcmp(section, "EOF") != 0)
	{
        printf("%s\n", section);
        if (strcmp(section, "NODE_COORD_SECTION") == 0)
		{
			parseNodeCoords(tsp);
		} else if (strcmp(section, "EDGE_DATA_SECTION") == 0)
		{
			parseEdgeData(tsp);
		} else if (strcmp(section, "DISPLAY_DATA_SECTION") == 0)
        {
            parseDisplayData(tsp); 
        } else if (strcmp(section, "EDGE_WEIGHT_SECTION") == 0)
		{
			parseEdgeWeight(tsp);
		} else
	    {
            printf("Section : %s\n", section);
			printf(" Unsupported format!\n");
			exit(1);
		}

        free(line);
        line = parseLine();
               
        sscanf(line, "%s", section);
	}

    freopen("/dev/tty", "r", stdin);
	return tsp;
}
