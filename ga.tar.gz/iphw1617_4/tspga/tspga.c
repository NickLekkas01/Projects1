#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "genetic_algorithm.h"
#include "tsp_parser.h"

char fileInputFlag = 0;
int* filename;

char checkFlag = 0;

int citySize;

// two dimension array. D(i,j) is the distance from city i to city j.
TSPi* tsp;
int** D;

int distance(Chromosome* c)
{
	int dist = 0;
	
	int i;
	for( i = 0; i < citySize - 1; i ++)
	{
		dist += tsp->D[((int*)c->genes)[i]][((int*)c->genes)[i+1]];
	}	
    
    dist += tsp->D[((int*)c->genes)[0]] [((int*)c->genes)[citySize-1]];

	return dist;
}

double fitness(Chromosome* c)
{
    int dist = distance(c);
    
    return 1.0 / (double) dist ;
}

//Fisher - Yates shuffle.
int* randomSequence(int size)
{
	int* temp = (int * ) malloc(sizeof(int) * size);
	int* seq = (int * ) malloc(sizeof(int) * size);
	
	int i;
	for( i = 0; i < size; i++)
	{
		temp[i] = i + 1;
	}
	
	for( i = 0 ; i < size; i++)
	{
		int k = drand() * (size - i ) ;
		
		int j = 0;
		
		while(temp[j] == 0)
			j++;
		while(k)
		{
			j++;
			k--;	
			while(temp[j] == 0)
				j++;
		}
				
		seq[i] =  temp[j] - 1;
		temp[j] = 0;
		
	}

    free(temp);
	
	return seq;
}

Chromosome* randChromosome()
{
    Chromosome* c = malloc(sizeof(Chromosome));

    c->genes = randomSequence(citySize);

    return c;
}

//Too slow do something faster!
char isWithin(Chromosome* c, int i, int j, int city)
{
	int k;
	for(k = i; k < j; k++)
	{
		if(((int*)c->genes)[k] ==  city)
    		return 1;
	}
	
	return 0;
}

void cross(Chromosome* a, Chromosome* b)
{
	
	int i = drand() * (citySize - 2);
	int j = i + drand() * (citySize - i - 2) + 1;
	
	Chromosome* ta = malloc(sizeof(Chromosome));
    Chromosome* tb = malloc(sizeof(Chromosome));
	
	ta->genes = (int *)malloc(sizeof(int)* citySize);
	tb->genes = (int *)malloc(sizeof(int)* citySize);
	
	int k;
	int l = j, m = j;
	
	for(k = 0; k < i; k++)
	{
		while(isWithin(a, i, j, ((int*)b->genes)[l % citySize]))
		{
			l++;
		}
		
		((int*)ta->genes)[k] = ((int*)b->genes)[l++%citySize];
		
		while(isWithin(b, i, j, ((int*)a->genes)[m % citySize]))
		{
			m++;
		}
		
		((int*)tb->genes)[k] = ((int*)a->genes)[m++%citySize];
	}
	
	for(k = i; k < j; k++)
	{
		((int*)ta->genes)[k] = ((int*)a->genes)[k];
		((int*)tb->genes)[k] = ((int*)b->genes)[k];
	}
	
	for(k = j; k < citySize; k++)
	{
		while(isWithin(a, i, j, ((int*)b->genes)[l % citySize]))
		{
			l++;
		}
		
		((int*)ta->genes)[k] = ((int*)b->genes)[l++%citySize];
		
		while(isWithin(b, i, j, ((int*)a->genes)[m % citySize]))
		{
			m++;
		}
		
		((int*)tb->genes)[k] = ((int*)a->genes)[m++%citySize];
	}
		
}

void mutate(Chromosome* c, int gene)
{
    int i = drand() * (citySize - 1);
    int j = drand() * (citySize - 2);

    if( j >= i)
        j++;
    int temp = ((int*) c->genes)[i];
    ((int*)c->genes)[i] = ((int*)c->genes)[j];
    ((int*)c->genes)[j] = temp;
}

void parseArguments(int argc, int* argv[], GeneticAlgorithm* algo)
{

	algo->populationSize = 1000;
	algo->generationsSize = 20;
	algo->fitnessGoal = 100000;

	algo->crossingPropability = 0.3;
	algo->mutationPropability = 0.1;
	
	int i;
	for( i = 1; i < argc; i++)
	{
		int * option = argv[i];
		if(strcmp(option, "-P") == 0)
		{
			algo->populationSize = atoi(argv[++i]);
		}else if(strcmp(option, "-G") == 0)
		{
			algo->generationsSize = atoi(argv[++i]);
		}else if(strcmp(option, "-FT") == 0)
		{
			algo->fitnessGoal =  atoi(argv[++i]);
		}else if(strcmp(option, "-PC") == 0)
		{
			sscanf(argv[++i], "%lf", &(algo->crossingPropability));
		}else if(strcmp(option, "-PM") == 0)
		{
			sscanf(argv[++i], "%lf", &(algo->mutationPropability));
		}else if(strcmp(option, "-c") == 0)
		{
			checkFlag = 1;
		}else if(strcmp(option, "-i") == 0)
		{
			fileInputFlag = 1;
			filename = argv[++i];
            freopen(filename, "r", stdin);
        }else
		{
			printf("You dummy !! Look at the README for the proper usage format!!");
			exit(1);
		}
	}
}

Chromosome* copy(Chromosome* c)
{
	Chromosome* copy = malloc(sizeof(Chromosome));

	copy->fitness = c->fitness;
	copy->genes = (int*) malloc(sizeof(int) * citySize);
	
	int i;
	for( i =0 ; i < citySize; i++)
	{
		((int*)copy->genes)[i] = ((int*)c->genes)[i];
	}
	
	return copy;
}

void parseInput()
{
	scanf("%d", &citySize);

    tsp = malloc(sizeof(TSPi));

	tsp->D = (int **) malloc(sizeof(int*) * citySize);
	
	int i;
	for(i = 0; i < citySize; i++)
	{
		tsp->D[i] = (int *) malloc(sizeof(int) * citySize);
	}
	
	for( i = 0; i < citySize; i++)
	{
		int j;
		tsp->D[i][i] = 0;

		for(j = i+1; j < citySize; j++)
		{
			int temp;
			scanf("%d", &temp);
			tsp->D[i][j] = tsp->D[j] [i] = temp;
		}
	}
}

void geneticAlgorithm(GeneticAlgorithm* algo)
{

    algo->randChromosome = &randChromosome;
    algo->fitness = &fitness;
    algo->cross = &cross;
    algo->mutate = &mutate;
    algo->copy = &copy;
    algo->drand = &drand;

	srand(time(NULL));

    Chromosome* max = apply(algo);

    int i;
    for( i = 0; i < citySize-1; i++)
        printf("%d ", ((int*)max->genes)[i] + 1);
 	printf("%d\n%d\n", ((int*)max->genes)[citySize-1], distance(max));

}

int main(int argc, int* argv[])
{
    GeneticAlgorithm algo;
    
	parseArguments(argc, argv, &algo);
	
    if(fileInputFlag)
    {
        tsp = parse(filename);
        citySize = tsp->dimension;
    }else
    {
        parseInput();
        algo.geneSize = citySize;
    }


	if( checkFlag)
	{
		int* seq = malloc(sizeof(int) * citySize);
		
        Chromosome path;
		path.genes = malloc(sizeof(int) * citySize);
		
        int i;
		for(i = 0; i < citySize; i++)
		{
			int temp;
			scanf( "%d", &temp);
			
			if(!(temp > 0 && temp <= citySize) || seq[temp-1] != 0)
			{
				//TODO print error message.
				exit(0);
			}
			seq[temp -1] = 1;
			((int*)path.genes)[i] = temp-1;
		}
		
		printf("Path length : %d\n", distance(&path));
	}else 
	{
		geneticAlgorithm(&algo);
	}

    return 0;
 	
}
