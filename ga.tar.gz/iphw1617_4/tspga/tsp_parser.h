#ifndef TSP_PARSER_H
#define TSP_PARSER_H

typedef enum TSPType            {TSP, ATSP, SOP, HCP, CVRP, TOUR} TSPType;
typedef enum EdgeWeightType     {EXPLICIT, EUC_2D, EUC_3D, MAX_2D, MAX_3D, MAN_2D,
MAN_3D, CEIL_2D, GEO, ATT, XRAY1, XRAY2, SPECIAL} EdgeWeightType;
typedef enum EdgeWeightFormat     {FUNCTION, FULL_MATRIX, UPPER_ROW, LOWER_ROW,
UPPER_DIAG_ROW, LOWER_DIAG_ROW, UPPER_COL, LOWER_COL, UPPER_DIAG_COL,
LOWER_DIAG_COL} EdgeWeightFormat;
typedef enum EdgeDataFormat     {EDGE_LIST, ADJ_LIST} EdgeDataFormat;
typedef enum NodeCoordType      {TWOD_COORDS, THREED_COORDS, NO_COORDS} NodeCoordType;
typedef enum DisplayDataType    {COORD_DISPLAY, TWOD_DISPLAY, NO_DISPLAY} DisplayDataType;

typedef struct TSP
{
    char* name;
    char* comment;

    int** nodeCoords;

    TSPType type;
    int dimension;
    EdgeWeightType weightType;
    EdgeWeightFormat weightFormat;
    EdgeDataFormat dataFormat;
    NodeCoordType coordType;
    DisplayDataType displayType;

    int** D;
} TSPi ;

TSPi* parse(char* filename);

#endif

