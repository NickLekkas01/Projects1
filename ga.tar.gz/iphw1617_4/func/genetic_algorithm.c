#include "genetic_algorithm.h"
#include <stdio.h>
#include <stdlib.h>
#include <float.h>

double drand()
{
    return ((double) rand()) / (double) RAND_MAX ;
}

int lowerBound(GeneticAlgorithm* algo, double value)
{
    int low = 0;
    int high = algo->populationSize;

    if(algo->sums[high] == value)
        return high - 1;

    while ( low + 1 < high )
    {
        int mid = (low + high) / 2;

        if( value == algo->sums[mid])
            return mid;
        else if ( value < algo->sums[mid])
            high = mid;
        else
            low = mid;
    }
    
    return low;
}

int cmpChromosomes(const void * a, const void * b)
{
    Chromosome* ca = (Chromosome*) a;
    Chromosome* cb = (Chromosome*) b;

    if( ca->fitness > cb->fitness )
        return -1;
    else if ( ca->fitness < cb->fitness )
        return 1;
    return 0;
}

void swap( void* a, void* b)
{
    void* temp = a;
    a = b;
    b = temp;
}

void init_population(GeneticAlgorithm* algo)
{
    algo->sums = malloc(sizeof(double) * (algo->populationSize +1));
    algo->population = malloc(sizeof(Chromosome) * algo->populationSize);
    algo->temp = malloc(sizeof(Chromosome) * algo->populationSize);

    int i;
    for( i = 0; i < algo->populationSize; i++)
    {
        Chromosome* c = algo->randChromosome();

        algo->population[i] = *c;
    }
}

Chromosome* compute(GeneticAlgorithm* algo)
{
    Chromosome* max = NULL;
    algo->sums[0] = 0.0;

    int i;
    for( i = 0; i < algo->populationSize; i++)
    {
        Chromosome* c = &algo->population[i];
        c->fitness = algo->fitness(c);
        algo->sums[i+1] = c->fitness + algo->sums[i];
    
        if(max == NULL || c->fitness > max->fitness)
            max = c;
    }

    return max;
}

void selection(GeneticAlgorithm* algo)
{
    int i = 0;

    /* Zero value means no elitism. */
    if( algo->elites )
    {
        int j;
        for( j = 0; j < algo->populationSize; j++)
        {
            algo->temp[j] = algo->population[j];
        }

        qsort(algo->temp, algo->populationSize, sizeof(Chromosome),
        cmpChromosomes);

        i = algo -> elites ;
    }

    for( ; i < algo->populationSize; i++)
    {
        double r = algo->drand() * (algo->sums[algo->populationSize] -
        DBL_MIN ) ;

        int pos = lowerBound(algo, r);
            
        algo->temp[i] = algo->population[pos];
    }

    swap(algo->population, algo->temp);
}

void crossing(GeneticAlgorithm* algo)
{
    int i ;
    for( i = 0; i < algo->populationSize - 1; i+=2)
    {   
        if( algo->drand() < algo->crossingPropability )
        {
            algo->cross(&algo->population[i], &algo->population[i+1]);
        }
    }
}

void mutation(GeneticAlgorithm* algo)
{
    int i;
    for( i = 0; i < algo->populationSize; i++)
    {
        int g;
        for( g = 0; g < algo->geneSize; g++)
        {
            if( algo->drand() < algo->mutationPropability )
            {
                algo->mutate(&algo->population[i], g);
            }   
        }
    }
}

Chromosome* apply(GeneticAlgorithm* algo)
{
    init_population(algo);

    Chromosome* max = NULL;

    int g;
    for( g = 0; g <= algo->generationsSize; g++)
    {
       Chromosome* genMax = compute(algo); 

        /* A huge and unreadable printf, just skip this part not match to see. */
        double averageFit = 
            algo->sums[algo->populationSize] / 
            (double) algo->populationSize;
    
//        printf("Generation %5d : AvgFit %6.6lf BestFit %6.6lf \n", g, 
//                averageFit, genMax->fitness);

        /* Update all time max. */
        if( max == NULL || genMax->fitness > max->fitness )
            max = algo->copy(genMax);

        /* Ladies and Gentlemen, we have winner! */
        if( max->fitness > algo->fitnessGoal )
            break;
        
        selection(algo);
        crossing(algo);
        mutation(algo);
    }

    
    return max;

}
