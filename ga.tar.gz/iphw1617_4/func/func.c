#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "genetic_algorithm.h"

int variableSize;

double fitness(Chromosome* c)
{
	double value;
	int i;
	value = 2 * variableSize;

	for (i = 0; i < variableSize; i++)
	{
		value -= 0.1 * cos(5 * M_PI * ((double*)c->genes)[i]);
		value += ((double*)c->genes)[i] * ((double*)c->genes)[i];
	}
	return value;
}

Chromosome* randChromosome()
{
    Chromosome* c = malloc(sizeof(Chromosome));

    c->genes = malloc(sizeof(double) * variableSize);

    int i;
    for( i=0; i < variableSize; i ++)
    {
        ((double*)c->genes)[i] = drand();
    }

    return c;
}

void cross(Chromosome* a, Chromosome* b)
{
	int i = (rand() % (variableSize - 1)) + 1;
	
	Chromosome* ta = malloc(sizeof(Chromosome));
	Chromosome* tb = malloc(sizeof(Chromosome));
	
	ta->genes =  malloc(sizeof(double)*variableSize);
	tb->genes =  malloc(sizeof(double)*variableSize);
	
	int j;
	for(j = 0; j < i; j++)
	{
		((double*)ta->genes)[j] = ((double*)a->genes)[j];
		((double*)tb->genes)[j] = ((double*)b->genes)[j];
	}

	for(j = i; j < variableSize; j++)
	{
		((double*)ta->genes)[j] = ((double*)b->genes)[j];
		((double*)tb->genes)[j] = ((double*)a->genes)[j];
	}
	
//    free(a);
    a = ta;

 //   free(b);
    b = tb;
}

void mutate(Chromosome* c, int gene)
{
    ((double*)c->genes)[gene] = (drand() * 2) - 1;
}

void parseArguments(int argc, int* argv[], GeneticAlgorithm* algo)
{
	algo->populationSize = 100;
	algo->generationsSize = 100;
	algo->fitnessGoal = 1024;
	algo->crossingPropability = 0.3;
    algo->mutationPropability = 0.1;
    algo->elites = 50;

    variableSize = 5;

	int i;
	for( i = 1; i < argc; i++)
	{
		int* option = argv[i];
		if(strcmp(option, "-P") == 0)
		{
			algo->populationSize = atoi(argv[++i]);
		}else if(strcmp(option, "-G") == 0)
		{
            algo->generationsSize = atoi(argv[++i]);
		}else if(strcmp(option, "-FT") == 0)
		{
			algo->fitnessGoal =  atoi(argv[++i]);
		}else if(strcmp(option, "-PC") == 0)
		{
			sscanf(argv[++i], "%lf", &(algo->crossingPropability));
		}else if(strcmp(option, "-PM") == 0)
		{
			sscanf(argv[++i], "%lf", &(algo->mutationPropability));
		}else if(strcmp(option, "-N") == 0)
		{
			variableSize = atoi(argv[++i]);
		}else
		{
			printf("You dummy! Look at the README for the proper usage format!!");
			exit(1);
		}
	}
}

Chromosome* copy(Chromosome* c)
{
	
	Chromosome* copy = malloc(sizeof(Chromosome));

	copy->fitness = c->fitness;
	copy->genes = (double*) malloc(sizeof(double) * variableSize);
	
	int i;
	for( i = 0 ; i < variableSize; i++)
	{
		((double*)copy->genes)[i] = ((double*)c->genes)[i];
	}
	
	return copy;
}

int main(int argc, int* argv[])
{
    GeneticAlgorithm algo;

    algo.randChromosome = &randChromosome;
    algo.fitness = &fitness;
    algo.cross = &cross;
    algo.mutate = &mutate;
    algo.copy = &copy;
    algo.drand = &drand;

    parseArguments(argc, argv, &algo);
	
	srand(time(0));

    Chromosome* max = apply(&algo);
	
	printf("Best Guess : (");
	
	int i;
	for(i = 0; i < variableSize - 1; i++)
	{
		printf("x%d = %lf, ", i, ((double*)max->genes)[i]);
	}
	
	printf("x%d = %lf) -> %lf \n", variableSize -1,
        ((double*)max->genes)[variableSize - 1],  max->fitness);
}
