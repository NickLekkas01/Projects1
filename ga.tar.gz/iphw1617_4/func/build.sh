gcc -o func func.c genetic_algorithm.c -lm
