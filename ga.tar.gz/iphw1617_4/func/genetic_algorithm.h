
#ifndef GENETIC_ALGO_H
#define GENETIC_ALGO_H

double drand();

typedef struct Chromosome
{
    void* genes;
    double fitness;
} Chromosome;

typedef struct GeneticAlgorithm
{
   Chromosome* (*randChromosome)();
   double (*fitness)(Chromosome*);
   void (*cross)(Chromosome*, Chromosome*);
   void (*mutate)(Chromosome*, int gene);

   Chromosome* (*copy)(Chromosome*);
    
    /* A function that generates a random double in the [0,1] range. */
    double (*drand) () ;

   int geneSize;
   int populationSize;
   int generationsSize;

    int elites;
    
   double fitnessGoal;

   double crossingPropability;
   double mutationPropability;

    /* These field need no values, they are initiated by apply() */
    Chromosome* population;
    Chromosome* temp;

    double* sums;

} GeneticAlgorithm;

Chromosome* apply(GeneticAlgorithm*);

#endif
